var swiper = new Swiper(".myswiper", {
  //   direction: "vertical",
  loop: true,
  pagination: {
    el: ".swiper-pagination",
  },
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
});
const swiper2 = new Swiper(".trustslider", {
  loop: true,
  freeMode: true,
  freeModeMomentum: false,     // IMPORTANT: stops momentum "jump"
  slidesPerView: "auto",
  spaceBetween: 43,

  speed: 6000,                 // slow, smooth flow
  autoplay: {
    delay: 0,                  // no pause
    disableOnInteraction: false
  },

  allowTouchMove: false,       // no user dragging (optional)
});

var swiper3 = new Swiper('.work-swiper', {
  // Optional parameters
  loop: true,
  spaceBetween: 40,
  slidesPerView: "auto",
});
var swiper4 = new Swiper('.services-swiper', {
  // Optional parameters
  loop: true,
   freeMode: true,
  freeModeMomentum: false,     // IMPORTANT: stops momentum "jump"
  slidesPerView: "auto",
  spaceBetween: 43,

  speed: 6000,                 // slow, smooth flow
  autoplay: {
    delay: 0,                  // no pause
    disableOnInteraction: false
  },

  allowTouchMove: false,       // no user dragging (optional)
  spaceBetween: 35,
  slidesPerView: "auto",
});
